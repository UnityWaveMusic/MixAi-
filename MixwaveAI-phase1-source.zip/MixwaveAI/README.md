# MIXWAVE AI

Two-plugin VST3 system for FL Studio (Windows x64): **MIXWAVE Track** (one per mixer insert) and **MIXWAVE Hub** (on the Master).

## Build on Windows
Requirements: Visual Studio 2022 (Desktop development with C++) or Build Tools, Git, CMake 3.22+.

    powershell -ExecutionPolicy Bypass -File scripts\build.ps1

Result: `dist\MIXWAVE-AI-Phase1-Windows-x64.zip` (plugins + install script + README).

## Build without a Windows toolchain
Push this folder to a GitHub repository and run the workflow **Build MIXWAVE AI (Windows x64)**
(Actions tab > Run workflow). Download the zip from the run's *Artifacts*.

## Install
See `packaging/README_INSTALL.txt`.
